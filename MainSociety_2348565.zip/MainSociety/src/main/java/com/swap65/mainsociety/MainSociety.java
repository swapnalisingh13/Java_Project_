/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.swap65.mainsociety;

/**
 *
 * @author Swapnali_singh
 */
public class MainSociety {

    public static void main(String[] args) {
        Login_Form loginForm = new Login_Form();
        loginForm.setVisible(true);
    }
}
